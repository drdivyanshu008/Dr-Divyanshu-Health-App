import 'package:equatable/equatable.dart';

class ConsultationModel extends Equatable {
  final String id;
  final String name;
  final String phone;
  final String email;
  final int age;
  final String gender;
  final List<String> medicalConditions;
  final String consultationType;
  final DateTime date;
  final String time;
  final DateTime createdAt;
  final String status;

  const ConsultationModel({
    required this.id,
    required this.name,
    required this.phone,
    required this.email,
    required this.age,
    required this.gender,
    required this.medicalConditions,
    required this.consultationType,
    required this.date,
    required this.time,
    required this.createdAt,
    this.status = 'pending',
  });

  factory ConsultationModel.fromJson(Map<String, dynamic> json) {
    return ConsultationModel(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      phone: json['phone'] ?? '',
      email: json['email'] ?? '',
      age: json['age'] ?? 0,
      gender: json['gender'] ?? '',
      medicalConditions: List<String>.from(json['medicalConditions'] ?? []),
      consultationType: json['consultationType'] ?? '',
      date: DateTime.parse(json['date'] ?? DateTime.now().toIso8601String()),
      time: json['time'] ?? '',
      createdAt: DateTime.parse(json['createdAt'] ?? DateTime.now().toIso8601String()),
      status: json['status'] ?? 'pending',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'phone': phone,
      'email': email,
      'age': age,
      'gender': gender,
      'medicalConditions': medicalConditions,
      'consultationType': consultationType,
      'date': date.toIso8601String(),
      'time': time,
      'createdAt': createdAt.toIso8601String(),
      'status': status,
    };
  }

  Map<String, dynamic> toGoogleSheetsRow() {
    return {
      'ID': id,
      'Name': name,
      'Phone': phone,
      'Email': email,
      'Age': age.toString(),
      'Gender': gender,
      'Medical Conditions': medicalConditions.join(', '),
      'Consultation Type': consultationType,
      'Date': date.toString().split(' ')[0],
      'Time': time,
      'Created At': createdAt.toString(),
      'Status': status,
    };
  }

  ConsultationModel copyWith({
    String? id,
    String? name,
    String? phone,
    String? email,
    int? age,
    String? gender,
    List<String>? medicalConditions,
    String? consultationType,
    DateTime? date,
    String? time,
    DateTime? createdAt,
    String? status,
  }) {
    return ConsultationModel(
      id: id ?? this.id,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      email: email ?? this.email,
      age: age ?? this.age,
      gender: gender ?? this.gender,
      medicalConditions: medicalConditions ?? this.medicalConditions,
      consultationType: consultationType ?? this.consultationType,
      date: date ?? this.date,
      time: time ?? this.time,
      createdAt: createdAt ?? this.createdAt,
      status: status ?? this.status,
    );
  }

  @override
  List<Object?> get props => [
        id,
        name,
        phone,
        email,
        age,
        gender,
        medicalConditions,
        consultationType,
        date,
        time,
        createdAt,
        status,
      ];
}

