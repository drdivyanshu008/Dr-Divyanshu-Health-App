import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:dr_divyanshu_health_app/main.dart';

void main() {
  testWidgets('App loads and displays home page', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(const DrDivyanshuHealthApp());

    // Verify that the app loads and displays the greeting
    expect(find.text('Dr. Divyanshu Patel'), findsOneWidget);
    
    // Verify that module tiles are displayed
    expect(find.text('Consultation Booking'), findsOneWidget);
    expect(find.text('Ayurveda Healing Zone'), findsOneWidget);
  });
}

