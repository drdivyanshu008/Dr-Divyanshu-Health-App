package com.drdivyanshu.health.dr_divyanshu_health_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
